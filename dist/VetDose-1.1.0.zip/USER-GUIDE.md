# VetDose 1.1

Calculadora matemática para uso veterinario en caninos y felinos. **No contiene, propone ni descarga dosis farmacológicas.** El profesional introduce cada pauta, concentración, frecuencia y parámetro. Un cálculo correcto no determina que una administración sea clínicamente adecuada.

**Guía para usuarios:** [Descargar PDF de 10 páginas](https://github.com/julve/vetdose/raw/refs/heads/vetdose-v1.0/docs/Guia-de-usuario-VetDose.pdf) · [Ver el PDF en GitHub](docs/Guia-de-usuario-VetDose.pdf). Incluye uso en teléfono, cálculos con datos ficticios, biblioteca, respaldos y solución de problemas. Puedes descargar el archivo y enviarlo por WhatsApp. Si el repositorio es privado, GitHub requiere una cuenta con acceso para descargarlo; los destinatarios del archivo PDF ya descargado no necesitan entrar a GitHub.

La calculadora funciona sin cuentas, suscripciones, CDN, fuentes remotas, telemetría ni almacenamiento de datos en la nube. Se puede distribuir como archivo local o como sitio estático en GitHub Pages. El alojamiento entrega el código de la aplicación; los cálculos y todos los datos de biblioteca permanecen en el navegador. El identificador de paciente solo permanece en memoria durante la sesión; no forma parte de los respaldos. El botón de impresión permite incluirlo expresamente en el resultado impreso.

## Ayudas de la versión 1.1

- **\* Obligatorio:** identifica los datos necesarios para la operación elegida. Las unidades y opciones que ya tienen una selección también se marcan para que se revisen.
- La frecuencia lleva * en una dosis diaria; en una dosis por administración es opcional. El total del tratamiento requiere tanto frecuencia como duración.
- Un vial requiere volumen final; el diluyente añadido es informativo. El factor gotas/mL es opcional para obtener mL y necesario para mostrar gotas.
- En contenido medido se requiere la cantidad de preparación, sin exigir una dosis. Frecuencia y duración se desactivan y el resultado las indica como no aplicables. Especie, peso, principio activo y datos de presentación siguen siendo necesarios.
- En Biblioteca los * indican lo necesario para guardar. Una pauta admite dosis puntual o un intervalo mínimo–máximo completo; al introducir un extremo se requieren ambos. Los valores cero se reconocen como entradas explícitas.
- Todas las cajas tienen ayuda debajo, asociada al control para lectores de pantalla. Los ejemplos numéricos son ficticios, no se introducen automáticamente ni constituyen recomendaciones.
- Los símbolos acompañan los textos: reloj para frecuencia, gota para volumen, diana para dosis, frasco para presentación y libro para biblioteca. La información no depende solo del color o del icono.
- El manual actualizado se descarga desde **Configuración → Descargar guía PDF**. El esquema de biblioteca sigue siendo 1 y los respaldos existentes continúan siendo compatibles.

## Sitio web para teléfonos y computadoras

El sitio listo para publicar está en `docs/index.html`. Consulte [la guía de GitHub Pages](docs/HOSTING.md) para activarlo. La dirección prevista, una vez publicado, es **https://julve.github.io/vetdose/**. Tener el código en GitHub no activa por sí solo el sitio.

En el teléfono, abra ese enlace en **Safari o Chrome**. Puede compartir el enlace por WhatsApp; no hace falta enviar ni abrir un HTML adjunto. Si WhatsApp abre su visor interno, use **Abrir en el navegador**. Puede añadir el sitio a la pantalla de inicio como acceso directo desde su navegador.

La interfaz de teléfono tiene campos de una columna, entradas de 16 px para evitar zoom al enfocar en iOS, controles táctiles de al menos 44 px, menú inferior con espacio para el área segura de la pantalla y desplazamiento automático al resultado. También admite orientación horizontal y modo oscuro. Se verificó en emulación táctil de Chromium; no se afirma haber probado dispositivos físicos ni Safari.

**Cada visitante empieza con una biblioteca vacía y mantiene sus propios datos locales.** La biblioteca del autor no se publica ni se comparte automáticamente. Para trasladar la suya entre navegadores o dispositivos, exporte e importe JSON. GitHub sirve los archivos del sitio, pero la aplicación no envía dosis, bibliotecas ni identificadores a GitHub.

Necesita conexión para abrir o recargar el sitio web. Una vez cargado, puede calcular sin conexión mientras permanezca abierto. No se implementa una PWA con caché para recarga offline; el archivo portable sigue disponible como alternativa.

## Empezar sin instalar herramientas

Copie **`dist/VetDose.html`** a su computadora y ábralo con un navegador que permita ejecutar HTML local. Este único archivo incluye estilos y JavaScript; no necesita los archivos fuente, Node.js ni conexión a Internet para calcular.

También puede descargar el [paquete portable 1.1.0 con el manual PDF](https://github.com/julve/vetdose/raw/refs/heads/vetdose-v1.0/dist/VetDose-1.1.0.zip). Extraiga todo el ZIP: el PDF debe quedar junto al HTML para abrirlo desde Configuración. El paquete de la versión 1.0 se conserva como archivo de la entrega anterior.

El acceso a archivos locales puede estar restringido por el navegador, el sistema operativo o políticas administrativas. La apertura `file://` no garantiza almacenamiento persistente, ni una experiencia equivalente en iOS. En este entorno de desarrollo esa navegación está bloqueada por la política administrativa de Chromium y no pudo validarse. Se validó el mismo HTML servido por HTTP local y su cálculo después de desconectar la red.

**Exporte su biblioteca JSON antes de cerrar**, especialmente si trabaja con el HTML portable, navegación privada o un teléfono. El archivo HTML no incorpora automáticamente su biblioteca: transfiera también un respaldo JSON.

## Alternativa fiable para ejecutar y desarrollar

Requiere Node.js 20 o posterior, en Windows, macOS o Linux. Desde la carpeta del proyecto:

```sh
npm start
```

El servidor muestra su dirección y puerto: abra en su navegador la dirección `127.0.0.1`, puerto `4173`, usando HTTP. Es un servidor estático de su propia computadora, sin base de datos ni API. La biblioteca sigue guardándose exclusivamente en el navegador. No hace falta `npm install` para iniciar, construir o ejecutar las pruebas unitarias; esas operaciones usan módulos integrados de Node.js.

Para acceder desde un teléfono en la misma red local, inicie el servidor con la interfaz de red habilitada:

```sh
# macOS / Linux
HOST=0.0.0.0 npm start
```

```powershell
# PowerShell en Windows
$env:HOST = '0.0.0.0'
npm start
```

En Safari o Chrome del teléfono abra la dirección IP local de la computadora, puerto `4173`, usando HTTP. La computadora y el servidor deben permanecer encendidos para abrir o recargar la aplicación. El acceso a Internet no es necesario, pero sí la conexión a esa red local. Puede ser necesario autorizar el puerto en el firewall. Use una red de confianza; el servidor estático no tiene autenticación. Por defecto solo escucha en la propia computadora.

Este mecanismo evita depender de que iOS ejecute un archivo HTML desde Archivos. No instala una aplicación nativa ni ofrece una PWA con recarga offline. Cambiar IP, puerto, protocolo, navegador o perfil cambia el origen del almacenamiento: exporte e importe su JSON para trasladar datos. Los pasos para Windows, macOS y teléfonos son instrucciones de uso; las pruebas ejecutadas aquí fueron en Linux y Chromium.

## Uso de la calculadora

1. Seleccione canino o felino e introduzca un peso positivo en kg. El identificador es opcional.
2. Seleccione un medicamento de su biblioteca o utilice entrada manual. Identifique un único principio activo.
3. Escriba la dosis y su unidad, vía y frecuencia. Una dosis por día requiere intervalo en horas. Duración es opcional.
4. Seleccione la presentación e introduzca su contenido y unidad. Para líquidos introduzca también el volumen de referencia: por ejemplo, el denominador 5 de una concentración expresada por 5 mL. No se presupone 1 mL.
5. Pulse **Calcular cantidad** y revise la cantidad, el procedimiento, los datos y las advertencias.

Se aceptan decimales con punto o coma, sin separadores de miles. Las ocho unidades disponibles son mg/kg/dosis, mg/kg/día, µg/kg/dosis, µg/kg/día, mg/dosis, µg/dosis, UI/kg/dosis y UI/dosis. Cero es una dosis numéricamente válida y explícita; no se interpreta como campo vacío. No implica una indicación clínica.

Los cambios de la calculadora son temporales. Cambiar cualquier entrada invalida el resultado anterior. Para conservar una modificación, edite expresamente el medicamento en Biblioteca.

Una pauta registrada para otra especie se deshabilita y el motor bloquea su cálculo si estaba seleccionada al cambiar de especie. Cuando una pauta incluye mínimos y máximos, la dosis queda vacía al cargarla: debe elegir expresamente un valor dentro del intervalo. Para trabajar con otra unidad o fuera del intervalo debe seleccionar **Pauta manual**.

## Presentaciones y límites dimensionales

| Presentación | Datos requeridos | Resultado matemático |
| --- | --- | --- |
| Tableta | mg o µg por unidad | Tabletas decimales y fracción equivalente si es representable |
| Cápsula | mg o µg por unidad | Cápsulas; no presupone apertura o división |
| Solución / suspensión | mg o µg por volumen definido en mL | mL |
| Inyectable | mg, µg o UI por volumen definido en mL | mL |
| Vial reconstituido | Contenido total y volumen **final** en mL | mL; diluyente añadido es un dato informativo separado |
| Polvo / granulado | mg o µg por 1 g | g |
| Sobre | mg o µg por sobre | Sobres; sin asumir fraccionamiento |
| Porcentaje p/v | g de activo por 100 mL | mg/mL; cantidad en mL |
| Porcentaje p/p | g de activo por 100 g | mg/g; cantidad en g |
| Porcentaje v/v | mL de activo por 100 mL | Solo contenido en volumen medido; bloquea dosis de masa |
| Gotas | mg o µg por volumen definido en mL | mL y opcionalmente gotas con factor explícito del producto/dispositivo |
| Crema / ungüento | mg o µg por 1 g y cantidad medida | Solo contenido de activo; no dosis sistémica |

Para un tópico porcentual elija **Preparación porcentual** y **Contenido en cantidad medida**. No convierta el contenido obtenido en una pauta sistémica.

Las fracciones ½, ¼, ⅛ y ⅓ se pueden registrar como autorizadas en una tableta. Una coincidencia matemática no valida divisibilidad física, estabilidad ni idoneidad clínica. Las equivalencias fraccionarias son informativas; no se ajusta la dosis ni se redondea a unidades administrables. Tampoco se redondean gotas.

No se implementa conversión UI↔masa, incluso si se dispone de un factor: se conserva esa separación en la versión 1.1. No se inventan densidades para v/v. Aerosoles, parches, formulaciones especiales, liberación modificada y combinaciones de principios activos no se calculan. No existen ajustes renales o hepáticos, límites terapéuticos, toxicidad, CRI, fluidoterapia ni recomendaciones clínicas.

## Fórmulas y precisión

La representación interna de masa usa mg: 1 mg = 1000 µg. UI y volumen tienen dimensiones separadas.

```text
Activo por administración (por dosis) = dosis × peso, si la unidad es /kg
Administraciones por día = 24 / intervalo en horas
Activo por administración (dosis diaria) = activo diario / administraciones por día
Cantidad de presentación = activo por administración / concentración normalizada
Contenido medido = cantidad de preparación × concentración normalizada
```

La duración supone una administración inicial en t=0 y excluye el instante final del tratamiento. Número de administraciones = techo(días × 24 / intervalo en horas). Total de presentación = cantidad por administración × número de administraciones. Por ejemplo, un tratamiento matemático de 24 horas cada 10 horas contiene administraciones a las horas 0, 10 y 20. El profesional debe confirmar que esta convención corresponde al calendario deseado.

La cantidad diaria en intervalos mayores de 24 horas es un **promedio**; se advierte que no implica administrar a diario. Sin frecuencia no se calcula cantidad diaria ni total. Sin duración no se calcula el total.

Se usa aritmética IEEE-754 de JavaScript, con hasta 12 cifras significativas en la pantalla. No es aritmética decimal exacta. Se bloquean NaN, Infinity, entradas inválidas, divisiones por cero, desbordamientos detectados, subdesbordamientos detectados y conteos de administraciones fuera de los enteros seguros. No se redondean resultados no nulos a cero. Las diferencias flotantes en límites enteros del calendario se tratan con una tolerancia relativa de unas pocas unidades de precisión de máquina. Revise siempre unidades y capacidad real de medición.

## Biblioteca, respaldo y recuperación

La biblioteca está vacía al comenzar. Cada medicamento tiene identidad, principio activo, observaciones, precauciones, referencia y fecha de revisión. Sus pautas y presentaciones son registros separados con identificadores únicos. Puede agregar varias de cada una sin duplicar el medicamento.

- **Crear / editar:** Biblioteca → Nuevo medicamento o Editar → agregar pautas y presentaciones → Guardar medicamento.
- **Duplicar:** crea una copia editable con nuevos identificadores; todavía debe guardarla.
- **Eliminar:** requiere confirmación y elimina las asociaciones del medicamento.
- **Buscar / filtrar:** búsqueda por nombre o activo; filtro de especie según pautas registradas.
- **Exportar:** Configuración → Exportar biblioteca JSON. Compruebe que el archivo se haya descargado y guárdelo fuera del navegador.
- **Recuperar o trasladar:** Configuración → elegir JSON → Fusionar o Reemplazar → Validar e importar.

Los respaldos usan `schemaVersion: 1` y contienen `drugs`, con listas `regimens` y `presentations` anidadas. Se comprueban identificadores globalmente únicos, nombres, fechas, unidades, números, frecuencias, intervalos posológicos y estructuras completas. El límite de importación es 5 MB. Los datos adicionales no reconocidos se descartan; no se ejecuta contenido del archivo y todo texto se representa escapado en la interfaz.

**Fusionar** omite registros idénticos con el mismo identificador. Si ese identificador tiene cambios o hay un posible duplicado por nombre y activo, se bloquea toda la fusión: revise las copias o, con un respaldo previo, elija reemplazo. No existe fusión automática de cambios dentro de un medicamento. **Reemplazar** exige confirmación y sustituye la biblioteca completa; exporte antes una copia. Un archivo inválido no modifica los datos actuales.

Se utiliza `localStorage`: las escrituras individuales son síncronas y se comprueba el esquema antes de guardarlo. Si falla una escritura, se conservan la biblioteca anterior y el editor. Si el almacenamiento está denegado desde el inicio, se usa memoria con aviso y puede exportar la biblioteca. Los datos locales corruptos no se sobreescriben automáticamente: Configuración permite descargar su contenido original para recuperación y realizar un reemplazo explícito con un respaldo válido.

Use una sola pestaña para editar. Se detectan cambios externos mediante eventos de almacenamiento y comparación con la copia cargada; una pestaña con datos anteriores bloquea sus escrituras. Esto no constituye una base de datos transaccional entre pestañas. No se implementa sincronización, cifrado, protección de acceso al dispositivo, ni retención garantizada por el navegador. Las bibliotecas grandes pueden superar su cuota aunque el archivo sea válido. Mantenga respaldos fuera del dispositivo.

## Estructura y desarrollo

```text
index.html             Entrada de desarrollo
src/core.js            Unidades, normalización, cálculos y advertencias
src/library.js         Esquema, validación, persistencia y respaldos
src/ui.js              Iconos y ayudas contextuales de los campos
src/app.js             Interfaz y estado temporal, sin cálculos duplicados
src/styles.css         Diseño responsive, claro, oscuro e impresión
scripts/build.js       Empaquetado determinista sin dependencias
scripts/serve.js       Servidor HTTP estático local
tests/                 Casos matemáticos, biblioteca y flujos de navegador
dist/VetDose.html      Distribución autocontenida generada
docs/index.html        Mismo HTML, listo para GitHub Pages
docs/.nojekyll         Publicación estática sin procesamiento Jekyll
docs/HOSTING.md        Activación del sitio y actualización
docs/VALIDACION.md      Evidencia y límites de las pruebas ejecutadas
```

```sh
npm test
npm run build
```

Para las pruebas de interfaz instale la única dependencia de desarrollo, fijada en el lockfile:

```sh
npm ci --cache /workspace/.cache/npm
npm run test:ui
```

La ruta de caché anterior corresponde al entorno cloud; en otra computadora puede usar simplemente `npm ci`. Playwright Core **no** descarga un navegador: requiere Chromium ya instalado. Por defecto se busca `/usr/bin/chromium`. Defina `BROWSER_PATH` con la ruta del ejecutable en otra plataforma. El runner inicia y detiene su propio servidor en el puerto 4174 y escribe capturas y reporte JSON en `test-results/`, carpeta ignorada por Git.

El runner usa `--no-sandbox` para Chromium en este contenedor de pruebas aislado. Si su sistema permite el sandbox normal, ejecute con `BROWSER_SANDBOX=1`. Esta opción solo corresponde al navegador de pruebas y no altera la aplicación, TLS ni la validación de paquetes.

No hay dependencias de terceros en el producto distribuido. El empaquetador incorpora únicamente los cuatro módulos y los estilos locales; los datos de pruebas no se incluyen. Después de modificar fuentes, regenere tanto el archivo portable como `docs/index.html` con `npm run build` y repita los controles correspondientes. El ZIP portable es un paquete de distribución; actualícelo también al publicar una nueva versión.

### Regenerar la guía PDF

La guía está en `docs/Guia-de-usuario-VetDose.pdf`. Sus capturas usan datos ficticios y se guardan en `docs/guide-assets/`. Para regenerarla con Chromium, Playwright Core, Python y las fuentes DejaVu Sans instaladas:

```sh
node scripts/capture-guide.js
python3 -m pip install -r scripts/guide-requirements.txt
python3 scripts/generate-user-guide.py
python3 scripts/package-portable.py
```

Estas herramientas solo se necesitan para editar la documentación; no son dependencias de la app. Puede indicar la carpeta de fuentes TTF con `GUIDE_FONT_DIR`. El generador comprueba que la guía tenga las 10 páginas previstas; revise también las páginas renderizadas al modificar el contenido. Una vez publicado GitHub Pages desde `/docs`, el PDF también se sirve en la dirección del sitio seguida de `Guia-de-usuario-VetDose.pdf`.
